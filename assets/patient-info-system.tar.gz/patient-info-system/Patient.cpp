/*
 * Patient.cpp
 *
 * Class Description: Models a walk-in clinic patient.
 * Class Invariant: Each patient has a unique care card number.
 *                  This care card number must have 10 digits.
 *                  This care card number cannot be modified.
 *
 * Last modified on: June 9 2017
 * Author: Raiya Jessa
 */

#include <iostream>  // for cout
#include <string>  // for str.length()
#include "Patient.h"

using namespace std;

// Default Constructor
// Description: Create a patient with a care card number of "0000000000".
// Postcondition: All data members set to "To be entered",
//                except the care card number which is set to "0000000000".
Patient::Patient() {
  name = "To be entered";
  address = "To be entered";
  phone = "To be entered";
  email = "To be entered";
  careCard = "0000000000";
}

// Parameterized Constructor
// Description: Create a patient with the given care card number.
// Postcondition: If aCareCard does not have 10 digits, then care card is set to "0000000000".
//                All other data members set to "To be entered".
Patient::Patient(string aCareCard) {
  if (aCareCard.length() == 10) {  // check for length
    bool alldigits = true;  // check for only numbers
    unsigned int i;
    for (i = 0; i < 10; i++) {
      if (aCareCard[i] != '0' && aCareCard[i] != '1' && aCareCard[i] != '2' &&
      aCareCard[i] != '3' && aCareCard[i] != '4' && aCareCard[i] != '5' &&
      aCareCard[i] != '6' && aCareCard[i] != '7' && aCareCard[i] != '8' &&
      aCareCard[i] != '9') {
        alldigits = false;
      }
    }
    if (alldigits) {
      careCard = aCareCard;  // exactly 10 digits
    } else {
      careCard = "0000000000";  // not all numbers
    }
  } else {
    careCard = "0000000000";  // not 10 digits
  }
  name = "To be entered";
  address = "To be entered";
  phone = "To be entered";
  email = "To be entered";
}

// GETTERS AND SETTERS
// Pre-condition for all: a valid Patient object that actually exists in the system.

// Description: Returns patient's name.
string Patient::getName() const {
  return name;
}

// Description: Returns patient's address.
string Patient::getAddress() const {
  return address;
}

// Description: Returns patient's phone number.
string Patient::getPhone() const {
  return phone;
}

// Description: Returns patient's email.
string Patient::getEmail() const {
  return email;
}

// Description: Returns patient's care card number.
string Patient::getCareCard() const {
  return careCard;
}

// Description: Sets the patient's name.
void Patient::setName(const string aName) {
  name = aName;
}

// Description: Sets the patient's address.
void Patient::setAddress(const string anAddress) {
  address = anAddress;
}

// Description: Sets the patient's phone number.
void Patient::setPhone(const string aPhone) {
  phone = aPhone;
}

// Description: Sets the patient's email.
void Patient::setEmail(const string anEmail) {
  email = anEmail;
}

// OVERLOADED OPERATORS

// Description: Comparison operator. Compares "this" Patient object with "rhs" Patient object.
//              Returns true if both Patient objects have the same care card number.
bool Patient::operator==(const Patient & rhs) {  // note: rhs represents the location of another Patient object
  if (careCard == rhs.careCard) {
    return true;
  }
  return false;
}

// Description: Greater than operator. Compares "this" Patient object with "rhs" Patient object.
//              Returns true if the care card number of "this" Patient object is > the care card number of "rhs" Patient object.
bool Patient::operator>(const Patient & rhs) {  // note: rhs represents the location of another Patient object
  if (careCard > rhs.careCard) {  //getCareCard() ?
    return true;
  }
  return false;
}

// Description: Prints the content of "this" patient.
void Patient::printPatient( ) {
  cout << getCareCard();
  cout << ", Patient: " << getName();
  cout << ", " << getAddress();
  cout << ", " << getPhone();
  cout << ", " << getEmail() << endl;
}
