/*
 * List.cpp
 *
 * Class Description: A value-oriented List data collection ADT.
 * Class Invariant: Data collection with the following characteristics:
 *                   - Each element is unique (no duplicates).
 *                   - It is sorted by ascending sort order of its elements.
 *                   - Its data structure is expandable: when full, it expands to accommodate
 *                     new insertion. This is done unbeknown to the client code.
 *
 * Last modified on: June 12 2017
 * Author: Raiya Jessa
 */

#include <iostream>
#include <string>
#include "List.h"
#include "Patient.h"

using namespace std;

// Default constructor
List::List() {
  // Make array 2D by allocating space for 10 sub-arrays (each big enough to hold 1 Patient object)
  unsigned int i;
  for (i = 0; i < 10; i++) {
    elements[i] = new Patient[1];
  }

  // Set private fields
  elementCount[0] = 0;
  for (i = 0; i < 10; i++) {
    innerElementCount[i] = 0;
  }
  for (i = 0; i < 10; i++) {
    innerCapacity[i] = 1;
  }
}

// Copy constructor
List::List(const List& lst) {
  elementCount[0] = lst.elementCount[0];  // copy elementCount

  unsigned int i, j;
  for (i = 0; i < 10; i++) {
    innerElementCount[i] = lst.innerElementCount[i];  // copy inner array counts
    innerCapacity[i] = lst.innerCapacity[i];  // copy inner array capacities
    elements[i] = new Patient[innerCapacity[i]];  // allocate necessary space for
                                                  // each inner array
  }

  // copy all patient objects
  for (i = 0; i < 10; i++) {
    for (j = 0; j < innerElementCount[i]; j++) {
      elements[i][j] = lst.elements[i][j];
    }
  }
}

// Destructor
// Description: Deallocates all memory that was dynamically allocated by the list
List::~List() {
  // iterate through outer array and delete pointers
  // (don't need to delete actual Patient objects bc not dynamically allocated)
  unsigned int i;
  for (i = 0; i < 10; i++) {
    delete[] elements[i];
    elements[i] = NULL;
  }
}

// Description: returns the first digit of patient's care card number (after
// converting it to an integer)
int List::getFirstNumCC(const Patient& element) {
  return element.getCareCard()[0] - '0';
}


// *** Start of Public Interface ***

// Description: Returns the total element count currently stored in List.
// O(1)
int List::getElementCount() const {
  return elementCount[0];
}

// Description: Insert an element.
//              When "this" List is full, its data structure is expanded to accommodate
//              a new element. This is done unbeknown to the client code.
//              If the insertion is successful, true is returned otherwise, false is returned.
// Precondition: newElement must not already be in data collection.
// Postcondition: newElement inserted and the appropriate elementCount has been incremented.
bool List::insert(const Patient& newElement) {
  bool res = false;
  unsigned int i;
  int firstNum = getFirstNumCC(newElement);

  // check whether or not this patient already exists in the List, O(m)
  Patient* found = search(newElement);
  if (!found) {
    // patient is not a duplicate, so proceed with insertion

    // check whether sub-array is full, O(1)
    if (innerElementCount[firstNum] >= innerCapacity[firstNum]) {
      // sub-array is full, so allocate memory for a new sub-array that is twice
      // as big and copy over existing patients. O(1), amortized
      innerCapacity[firstNum] *= 2;
      Patient *newArr;
      newArr = new Patient[innerCapacity[firstNum]];
      for (i = 0; i < innerElementCount[firstNum]; i++) {
        newArr[i] = elements[firstNum][i];
      }

      delete[] elements[firstNum];  // deallocate memory associated w/ old sub-array
      elements[firstNum] = newArr;  // point pointer to new array
    }

    // if new patient is the first in its sub-array, simply add it in position 0
    if (innerElementCount[firstNum] == 0) {
      elements[firstNum][0] = newElement;
    } else {
      // insert the object into sub-array in sort order, O(m)
      // 1. find cell i in which new patient belongs
      i = 0;
      while (i < innerElementCount[firstNum] && !elements[firstNum][i].operator>(newElement)) {
        i++;
      }

      // 2. shift over patients with care cards > than new patient's rightwards to make space.
      // must iterate backwards so that elements don't get overwritten
      unsigned int j;
      for (j = innerElementCount[firstNum]; j > i; j--) {
        elements[firstNum][j] = elements[firstNum][j-1];
      }

      // 3. actually insert the new patient
      elements[firstNum][i] = newElement;
    }

    // update variables
    res = true;
    elementCount[0]++;
    innerElementCount[firstNum]++;
  }

  return res;
}

// Description: Remove an element.
//              If the removal is successful, true is returned otherwise, false is returned.
// Precondition: toBeRemoved must actually exist in the system.
// Postcondition: toBeRemoved is removed, the appropriate elementCount has been decremented.
// O(m)
bool List::remove(const Patient& toBeRemoved) {
  int firstNum = getFirstNumCC(toBeRemoved);

  // search for patient in sub-array
  bool found = false;
  unsigned int i;
  for (i = 0; i < innerElementCount[firstNum] && !found; i++) {
    if (elements[firstNum][i].operator==(toBeRemoved)) {
      // shift over remaining elements leftwards
      unsigned int j;
      for (j = i; j < innerElementCount[firstNum]-1; j++) {
        elements[firstNum][j] = elements[firstNum][j+1];
      }

      // update variables
      found = true;
      elementCount[0]--;
      innerElementCount[firstNum]--;
    }
  }

  return found;
}

// Description: Remove all elements.
// O(1)
void List::removeAll() {
  // update class fields
  elementCount[0] = 0;
  unsigned int i;
  for (i = 0; i < 10; i++) {
    innerElementCount[i] = 0;
  }
}

// Description: Search for target element and returns a pointer to it if found,
//              otherwise, returns NULL.
// Postcondition: if target's care card is found in List, a pointer to the match is returned.
// O(m)
Patient* List::search(const Patient& target) {
  int firstNum = getFirstNumCC(target);

  // Search sub-array
  Patient* res = NULL;
  bool found = false;
  unsigned int i;
  for (i = 0; i < innerElementCount[firstNum] && !found; i++) {
    if (elements[firstNum][i].operator==(target)) {
      res = &elements[firstNum][i];
      found = true;
    }
  }
  return res;
}

// Description: Prints all n elements stored in List in sort order and does so in O(n).
// Postcondition: all List elements printed by ascending care card number.
// O(n)
void List::printList() {
  unsigned int i, j;
  for (i = 0; i < 10; i++) {
    for (j = 0; j < innerElementCount[i]; j++) {
      elements[i][j].printPatient();
    }
  }
}

// *** End of Public Interface ***
