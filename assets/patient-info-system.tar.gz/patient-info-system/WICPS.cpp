/*
 * WICPS.cpp
 *
 * Description: A user interface (intended for staff at a walk-in clinic),
 *    allowing them to add, remove, modify, search for, or display patients
 *    in the system
 *
 * Last modified on: June 12 2017
 * Author: Raiya Jessa
 */

#include <iostream>
#include <string>  // for str.length()
#include "List.h"
#include "Patient.h"

using namespace std;


// Description: returns a new Patient object with a care card input by user
// (validated to ensure it's exactly 10 digits)
Patient getCareCard() {
  Patient patient;  // declare patient object
  string aCareCard = "";
  bool valid = false;
  while (not valid) {
    cout << "\nPlease enter the patient's 10-digit care card number\n(Note: this field cannot be changed): ";
    cin >> aCareCard;
    if (aCareCard.length() == 10) {
      bool alldigits = true;
      unsigned int i;
      for (i = 0; i < 10; i++) {
        if (aCareCard[i] != '0' && aCareCard[i] != '1' && aCareCard[i] != '2' &&
        aCareCard[i] != '3' && aCareCard[i] != '4' && aCareCard[i] != '5' &&
        aCareCard[i] != '6' && aCareCard[i] != '7' && aCareCard[i] != '8' &&
        aCareCard[i] != '9') {
          alldigits = false;
        }
      }
      if (alldigits) {
        patient = Patient(aCareCard);  // intialize patient using parameterized constructor
        valid = true;
      } else {
        cout << "Not all digits; please try again!" << endl;
      }
    } else {
      cout << "Not 10 characters long; please try again!" << endl;
    }
  }
  return patient;
}


// Description: guides user to create + insert new patient into system.
// Gives choice about setting care card vs using default, and asks user to fill in remaining fields
void addPatient(List* patients) {
  // create a new default patient
  Patient newPatient = Patient();

  // get patient's care card
  newPatient = getCareCard();

  // fill in other fields
  string aName = "", anAddress = "", aPhoneNum = "", anEmail = "";
  cout << "\nPlease enter the patient's info below:" << endl;
  // remove all leading whitespace -> ws
  cout << "Name: "; getline(cin >> ws, aName); newPatient.setName(aName);
  cout << "Address: "; getline(cin >> ws, anAddress); newPatient.setAddress(anAddress);
  cout << "Phone Number: "; getline(cin >> ws, aPhoneNum); newPatient.setPhone(aPhoneNum);
  cout << "Email: "; getline(cin >> ws, anEmail); newPatient.setEmail(anEmail);

  // now officially add the patient to the system
  bool res = patients->insert(newPatient);
  if (res) { cout << "\nSuccess! '" << newPatient.getName() << "' has been added to the system." << endl; }
  else { cout << "\nError! There is either not enough space left or this care card has already been used." << endl; }

  return;
}


// Description: removes a patient from system based on care card that user inputs
void removePatient(List* patients) {
  // get care card of patient to be removed (rather than getting name since
  // there can be multiple patients w/ same name)
  cout << "\nWhich patient would you like to remove?";
  Patient toBeRemoved = getCareCard();

  // make sure the patient actually exists in the system
  Patient* found = patients->search(toBeRemoved);

  // remove patient from the system
  if (found) {
    string name = found->getName();  // save their name before they're deleted
    bool res = patients->remove(*found);
    if (res) { cout << "\nSuccess! " << name << " has been removed from the system."; }
    else { cout << "\nError! This patient could not be found in the system." << endl; }
  } else {
    cout << "\nError! This patient could not be found in the system." << endl;
  }
  return;
}


// Description: removes all patients from the system
void removeAllPatients(List* patients) {
  patients->removeAll();
  cout << "\nSuccess! All patients have been removed from the system." << endl;
  return;
}


// Description: displays a patient's info based on care card that user inputs
void searchForPatient(List* patients) {
  // get care card of patient to be displayed
  cout << "\nWhich patient are you looking for?";
  Patient toBeDisplayed = getCareCard();

  // make sure the patient actually exists in the system
  Patient* found = patients->search(toBeDisplayed);

  if (found) {
    cout << "\nSuccess! Displaying " << found->getName() << "'s info:" << endl;
    found->printPatient();
  } else {
    cout << "\nError! This patient could not be found in the system." << endl;
  }
  return;
}


// Description: allows user to modify a patient's info based on care card that they input
// by repeatedly displaying a sub-menu until they choose to go back to the main menu
void modifyPatient(List* patients) {
  // get care card of patient to be removed
  cout << "\nWhich patient's info would you like to modify?";
  Patient toBeModified = getCareCard();

  // make sure the patient actually exists in the system
  Patient* found = patients->search(toBeModified);

  if (found) {

    // Display sub-menu
    bool done = false;
    char input = 0;

    while (not done) {
      cout << "\n--------------------------------------" << endl;
      cout << "~~~~~\tMODIFY PATIENT INFO\t ~~~~~" << endl;
      cout << "~~~~~ 1. Change Name\t\t ~~~~~" << endl;
      cout << "~~~~~ 2. Change Address\t\t ~~~~~" << endl;
      cout << "~~~~~ 3. Change Phone Number\t ~~~~~" << endl;
      cout << "~~~~~ 4. Change Email\t\t ~~~~~" << endl;
      cout << "~~~~~ 5. Back\t\t\t ~~~~~" << endl;
      cout << "--------------------------------------" << endl;
      cout << "Your choice: ";
      cin >> input;

      string aName = "", anAddress = "", aPhoneNum = "", anEmail = "";

      switch (input) {
        case '1' : cout << "\nNew name: "; getline(cin >> ws, aName); found->setName(aName);
          cout << "\nSuccess! " << found->getName() << "'s name has been updated." << endl; break;
        case '2' : cout << "\nNew address: "; getline(cin >> ws, anAddress); found->setAddress(anAddress);
          cout << "\nSuccess! " << found->getName() << "'s address has been updated." << endl; break;
        case '3' : cout << "\nNew phone number: "; getline(cin >> ws, aPhoneNum); found->setPhone(aPhoneNum);
          cout << "\nSuccess! " << found->getName() << "'s phone number has been updated." << endl; break;
        case '4' : cout << "\nNew email: "; getline(cin >> ws, anEmail); found->setEmail(anEmail);
          cout << "\nSuccess! " << found->getName() << "'s email address has been updated." << endl; break;
        case '5' : done = true; break;
        default: cout << "\nInvalid input; please try again!" << endl;
      }
    }


  } else {
    cout << "\nError! This patient could not be found in the system." << endl;
  }
  return;
}


// Description: prints list of patients
void displayPatients(List* patients) {
  cout << "\nDisplaying list of patients:" << endl;
  patients->printList();
}


int main(void) {

  cout << "\nWelcome to your Walk-in Clinic Patient Info System!" << endl;

  // Create an empty list
  List* infoSystem = new List();
  bool done = false;
  char input = 0;

  while (not done) {  // display menu to user
    cout << "\n--------------------------------------" << endl;
    cout << "~~~~~\t\tMENU\t\t ~~~~~" << endl;
    cout << "~~~~~ 1. Add a patient\t\t ~~~~~" << endl;
    cout << "~~~~~ 2. Remove a patient\t ~~~~~" << endl;
    cout << "~~~~~ 3. Remove all patients\t ~~~~~" << endl;
    cout << "~~~~~ 4. Search for a patient\t ~~~~~" << endl;
    cout << "~~~~~ 5. Modify patient info\t ~~~~~" << endl;
    cout << "~~~~~ 6. Display all patients\t ~~~~~" << endl;
    cout << "~~~~~ 7. Exit system\t\t ~~~~~" << endl;
    cout << "--------------------------------------" << endl;
    cout << "Your choice: ";
    cin >> input;

    switch(input) {
      case '1' : addPatient(infoSystem); break;
      case '2' : removePatient(infoSystem); break;
      case '3' : removeAllPatients(infoSystem); break;
      case '4' : searchForPatient(infoSystem); break;
      case '5' : modifyPatient(infoSystem); break;
      case '6' : displayPatients(infoSystem); break;
      case '7' : done = true; break;
      default: cout << "\nInvalid input; please try again!" << endl;
    }
    cout << "\nThere are now " << infoSystem->getElementCount() << " patient(s) in your info system." << endl;
  }

  cout << "\nThanks for visiting!\n";

  // free memory
  delete infoSystem;
  infoSystem = NULL;

  return 0;
}
